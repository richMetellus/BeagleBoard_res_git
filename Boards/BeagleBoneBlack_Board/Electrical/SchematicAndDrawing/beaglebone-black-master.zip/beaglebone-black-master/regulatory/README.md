# FCC: 
 * https://github.com/beagleboard/BeagleBone-Black/blob/master/regulatory/FCC/DSS%5FSZEM210200207301%20RPT.pdf
# CE:
 * https://github.com/beagleboard/BeagleBone-Black/blob/master/regulatory/CE/DSS%5FSZEM210200207401%20RPT.pdf
# REACH: 
# Export control:
 * https://github.com/beagleboard/BeagleBone-Black/blob/master/regulatory/BeagleBone-Export-Info.pdf
 * ECCN: 5A002A1
 * CCATS: G141473
